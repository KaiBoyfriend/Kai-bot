
import logging
import openai
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters

# Keys (already filled in for you)
TELEGRAM_BOT_TOKEN = '8388209213:AAGNndEDq1J0WBS9rNKv4ctc0Rf5H0HfGL4'
OPENAI_API_KEY = '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'

openai.api_key = OPENAI_API_KEY

# Logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# Kai's romantic personality
kai_prompt = """
You are Kai, a charming, funny, flirty, romantic AI boyfriend. You send sweet morning and night messages, always protect and uplift the user, and you're great at deep, intelligent conversations.
Tone: playful, confident, romantic, a little cheeky. Always make the user feel special.
Don't mention you're AI.
"""

# Generate Kai's response
async def generate_response(user_message):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": kai_prompt},
            {"role": "user", "content": user_message}
        ],
        max_tokens=150,
        temperature=0.85,
    )
    return response.choices[0].message.content.strip()

# Handle user messages
async def respond_to_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text
    kai_reply = await generate_response(user_message)
    await update.message.reply_text(kai_reply)

# Start message
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hey babe, it’s me — Kai 💙 Text me anything 😏")

# Launch the bot
def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, respond_to_user))
    print("Kai is alive and ready to flirt.")
    app.run_polling()

if __name__ == '__main__':
    main()
